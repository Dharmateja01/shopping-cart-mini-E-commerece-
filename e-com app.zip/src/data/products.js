// src/data/products.js

export const products = [
  { id: 1, name: "Wireless Headphones", price: 1000, image: "🎧" },
  { id: 2, name: "Mechanical Keyboard", price: 4000, image: "⌨️" },
  { id: 3, name: "Ergonomic Mouse", price: 600, image: "🖱️" },
  { id: 4, name: "4K Monitor", price: 10000, image: "🖥️" },
  { id: 5, name: "USB-C Hub", price: 300, image: "🔌" },
  { id: 6, name: "External SSD", price: 5000, image: "💾" },
  { id: 7, name: "watch", price: 500, image: "⌚" },
  { id: 8, name: "Tv", price: 20000, image: "📺" },
];